#!/bin/bash


if [ "$#" -ne 1 ]; then
  echo "$0: Необходимо указать каталог для создания файлов."
  exit 1
fi

directory="$1"


if [ ! -d "$directory" ]; then
  echo "$0: Указанный каталог не существует."
  exit 1
fi


for i in {1..1000}; do
  filename="${directory}/${i}.txt"
  echo $((i)) > "$filename" || { echo "$0: Ошибка при создании файла $filename."; exit 1; }
done


even_files="${directory}/even.txt"
odd_files="${directory}/odd.txt"


for i in {2..1000..2}; do
  filename="${directory}/${i}.txt"
  cat "$filename" >> "$even_files" || { echo "$0: Ошибка при объединении файла $filename в $even_files."; exit 1; }
done

for i in {1..1000..2}; do
  filename="${directory}/${i}.txt"
  cat "$filename" >> "$odd_files" || { echo "$0: Ошибка при объединении файла $filename в $odd_files."; exit 1; }
done

for i in {1..1000}; do
  filename="${directory}/${i}.txt"
  rm "$filename" || { echo "$0: Ошибка при удалении файла $filename."; exit 1; }
done


echo "$0: Сценарий выполнен успешно."

